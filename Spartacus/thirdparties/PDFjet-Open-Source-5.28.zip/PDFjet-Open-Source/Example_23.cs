using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;

using PDFjet.NET;


/**
 *  Example_23.cs
 *
 */
public class Example_23 {

    public Example_23() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_23.pdf", FileMode.Create)));

        Page page = new Page(pdf, Letter.PORTRAIT);

        Font f1 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        f1.SetSize(7f);

        Font f2 = new Font(pdf, CoreFont.HELVETICA);
        f2.SetSize(7f);

        List<List<Cell>> tableData = new List<List<Cell>>();

        List<Cell> row = new List<Cell>();

        Cell cell = new Cell(f1, "Hello");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);

        cell = new Cell(f1, "World");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);

        cell = new Cell(f1, "Next Column");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);

        cell = new Cell(f1, "Last Column");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);

        tableData.Add(row);

        row = new List<Cell>();
        cell = new Cell(f2, "This is a test:");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);
        cell = new Cell(f2,
"Here we are going to test the wrapCellText method.\tWe will create a table and place it near the bottom of the page. When we draw this table the text will wrap around the column edge and stay within the column.\nAll the white space characters will be stripped and replaced with a single space between the words.\tSo - let's  see how this is working:\nIf you are using this functionality to draw text - make the border invisible.\r\n        This white space should be replaced with a single space.");
        cell.SetColSpan(2);
        // cell.SetColSpan(3);
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        // cell.SetTextAlignment(Align.RIGHT);
        // cell.SetTextAlignment(Align.CENTER);
        row.Add(cell);
        row.Add(new Cell(f2, "Test 123"));
        cell = new Cell(f2, "Test 456");
        cell.SetTopPadding(5f);
        cell.SetBottomPadding(5f);
        row.Add(cell);
        tableData.Add(row);

        row = new List<Cell>();
        row.Add(new Cell(f2, "Another row. Make sure that this line of text will be wrappped around correctly too."));
        row.Add(new Cell(f2, "Yahoo!"));
        row.Add(new Cell(f2, "Test 789"));
        row.Add(new Cell(f2, "Test 000"));
        tableData.Add(row);

        Table table = new Table();
        table.SetData(tableData, Table.DATA_HAS_1_HEADER_ROWS);
        
        table.SetLocation(70f, 730f);
        table.SetColumnWidth(0, 100f);
        table.SetColumnWidth(1, 100f);
        table.WrapAroundCellText();
        // table.SetNoCellBorders();

        int numOfPages = table.GetNumberOfPages(page);
        while (true) {
            Point point = table.DrawOn(page);
            if (!table.HasMoreData()) break;
            page = new Page(pdf, Letter.PORTRAIT);
            table.SetLocation(70f, 30f);
        }

        pdf.Close();
    }
    

    public static void Main(String[] args) {
        try {
            new Example_23();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_23.cs
