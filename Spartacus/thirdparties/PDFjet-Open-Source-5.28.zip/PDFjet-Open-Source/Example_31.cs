using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_31.cs
 */
public class Example_31 {

    public Example_31() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_31.pdf", FileMode.Create)));

        Page page = new Page(pdf, Letter.PORTRAIT);

        Font f1 = new Font(
                pdf,
                new FileStream(
                        "fonts/Android/DroidSansDevanagari-Regular.ttf",
                        FileMode.Open,
                        FileAccess.Read),
                CodePage.UNICODE,
                Embed.YES);
        f1.SetSize(15f);

        Font f2 = new Font(
                pdf,
                new FileStream(
                        "fonts/Android/DroidSans.ttf",
                        FileMode.Open,
                        FileAccess.Read),
                CodePage.UNICODE,
                Embed.YES);
        f2.SetSize(15f);

        StringBuilder buf = new StringBuilder();
        StreamReader reader = new StreamReader(
                new FileStream("data/marathi.txt", FileMode.Open, FileAccess.Read));
        String line = null;
        while ((line = reader.ReadLine()) != null) {
            buf.Append(line + "\n");
        }
        reader.Close();

        TextBox textBox = new TextBox(f1, buf.ToString(), 500f, 300f);
        textBox.SetFallbackFont(f2);
        textBox.SetLocation(50f, 50f);
        textBox.SetNoBorders();
        textBox.DrawOn(page);

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_31();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_31.cs
