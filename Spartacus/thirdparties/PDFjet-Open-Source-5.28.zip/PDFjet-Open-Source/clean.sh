rm com/pdfjet/*.class
rm *.class
rm *.pdf
rm *.exe
rm *.mdb
rm *.jar
rm *.dll
