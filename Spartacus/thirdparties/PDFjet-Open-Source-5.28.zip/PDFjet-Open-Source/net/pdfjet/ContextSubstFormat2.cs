using System;

namespace PDFjet.NET {
public class ContextSubstFormat2 {
    int substFormat;
    int coverage;
    int classDef;
    int subClassSetCnt;
    int[] subClassSet;      // [subClassSetCnt]
}
}
