using System;

namespace PDFjet.NET {
class FeatureList {
    int featureCount;
    FeatureRecord[] featureRecord;  // [featureCount]
}
}
