using System;

namespace PDFjet.NET {
class LigatureSet {
    int ligatureCount;
    int[] ligature;     // [ligatureCount]
}
}
