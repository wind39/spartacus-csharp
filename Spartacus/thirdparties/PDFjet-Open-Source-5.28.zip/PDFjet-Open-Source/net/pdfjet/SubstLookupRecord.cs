using System;

namespace PDFjet.NET {
class SubstLookupRecord {
    int sequenceIndex;
    int lookupListIndex;
}
}
