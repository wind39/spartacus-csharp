using System;

namespace PDFjet.NET {
class Feature {
    int featureParams;
    int lookupCount;
    int[] lookupListIndex;  // [lookupCount]
}
}
