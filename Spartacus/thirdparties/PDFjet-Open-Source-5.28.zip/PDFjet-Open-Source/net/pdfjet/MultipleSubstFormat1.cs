using System;

namespace PDFjet.NET {
class MultipleSubstFormat1 {
    int substFormat;
    int coverage;
    int sequenceCount;
    int[] sequence;     // [sequenceCount]
}
}
