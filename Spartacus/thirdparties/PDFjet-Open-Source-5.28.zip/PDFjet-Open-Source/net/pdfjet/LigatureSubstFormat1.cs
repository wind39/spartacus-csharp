using System;

namespace PDFjet.NET {
class LigatureSubstFormat1 {
    int substFormat;
    int coverage;
    int ligSetCount;
    int[] legatureSet;  // [ligSetCount]
}
}
