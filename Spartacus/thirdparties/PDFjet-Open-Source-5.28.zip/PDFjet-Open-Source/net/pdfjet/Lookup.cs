using System;

namespace PDFjet.NET {
class Lookup {
    int lookupType;
    int lookupFlag;
    int subTableCount;
    int[] subTable;         // [subTableCount]
    int markFilteringSet;
}
}
