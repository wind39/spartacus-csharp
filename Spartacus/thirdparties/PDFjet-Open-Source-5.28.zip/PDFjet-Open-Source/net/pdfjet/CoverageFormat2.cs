using System;

namespace PDFjet.NET {
class CoverageFormat2 {
    int coverageFormat;
    int rangeCount;
    RangeRecord[] rangeRecord;  // [rangeCount]
}
}
