using System;

namespace PDFjet.NET {
class LigatureTable {
    int ligGlyph;
    int compCount;
    int[] component;    // [compCount - 1]
}
}
