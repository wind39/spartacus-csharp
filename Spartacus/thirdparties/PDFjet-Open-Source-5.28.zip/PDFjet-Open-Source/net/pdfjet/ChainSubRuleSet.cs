using System;

namespace PDFjet.NET {
class ChainSubRuleSet {
    int chainSubRuleCount;
    int[] chainSubRule;     // [chainSubRuleCount]
}
}
