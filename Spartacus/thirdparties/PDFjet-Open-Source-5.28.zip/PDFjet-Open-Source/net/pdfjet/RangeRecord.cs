using System;

namespace PDFjet.NET {
class RangeRecord {
    int start;
    int end;
    int startCoverageIndex;
}
}
