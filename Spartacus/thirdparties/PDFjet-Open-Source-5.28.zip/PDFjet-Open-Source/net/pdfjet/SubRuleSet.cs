using System;

namespace PDFjet.NET {
class SubRuleSet {
    int subRuleCount;
    int[] subRule;
}
}
