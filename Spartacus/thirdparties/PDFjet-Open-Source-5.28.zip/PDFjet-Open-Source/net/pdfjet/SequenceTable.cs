using System;

namespace PDFjet.NET {
class SequenceTable {
    int glyphCount;
    int[] substitute;   // [glyphCount]
}
}
