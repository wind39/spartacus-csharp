using System;

namespace PDFjet.NET {
class SingleSubstFormat1 {
    int substFormat;
    int coverage;
    int deltaGlyphID;
}
}
