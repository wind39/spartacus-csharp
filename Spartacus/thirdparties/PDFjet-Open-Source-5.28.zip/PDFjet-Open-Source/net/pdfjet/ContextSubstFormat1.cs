using System;

namespace PDFjet.NET {
public class ContextSubstFormat1 {
    int substFormat;
    int coverage;
    int subRuleSetCount;
    int[] subRuleSet;       // [subRuleSetCount]
}
}
