using System;

namespace PDFjet.NET {
class ChainContextSubstFormat1 {
    int substFormat;
    int coverage;
    int chainSubRuleSetCount;
    int[] chainSubRuleSet;      // [chainSubRuleSetCount]
}
}
