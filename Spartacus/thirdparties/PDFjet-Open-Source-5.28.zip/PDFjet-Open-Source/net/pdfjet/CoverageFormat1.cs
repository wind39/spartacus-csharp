using System;

namespace PDFjet.NET {
class CoverageFormat1 {
    int coverageFormat;
    int glyphCount;
    int[] glyphArray;   // [glyphCount]
}
}
