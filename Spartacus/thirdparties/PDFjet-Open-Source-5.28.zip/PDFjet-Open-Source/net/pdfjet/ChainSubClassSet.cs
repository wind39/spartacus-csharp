using System;

namespace PDFjet.NET {
class ChainSubClassSet {
    int chainSubClassRuleCount;
    int[] chainSubClassRule;    // [chainSubClassRuleCount]
}
}
