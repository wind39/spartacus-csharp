using System;

namespace PDFjet.NET {
class SubClassSet {
    int subClassRuleCnt;
    int[] subClassRule;
}
}
