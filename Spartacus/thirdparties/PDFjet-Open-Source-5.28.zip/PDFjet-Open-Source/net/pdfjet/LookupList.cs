using System;

namespace PDFjet.NET {
class LookupList {
    int lookupCount;
    int[] lookup;       // [lookupCount]
}
}
