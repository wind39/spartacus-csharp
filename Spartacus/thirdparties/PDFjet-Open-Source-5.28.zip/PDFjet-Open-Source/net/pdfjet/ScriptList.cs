using System;

namespace PDFjet.NET {
class ScriptList {
    int scriptCount;                // Number of ScriptRecords
    ScriptRecord[] scriptRecord;    // Array of ScriptRecords - listed alphabetically by ScriptTag
}
}
