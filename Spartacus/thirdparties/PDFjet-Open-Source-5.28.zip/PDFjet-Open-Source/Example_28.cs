using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_28.cs
 *
 */
public class Example_28 {

    public Example_28() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_28.pdf", FileMode.Create)));

        Font f1 = new Font(pdf, new BufferedStream(
                new FileStream(
                        "fonts/Android/DroidSans.ttf", FileMode.Open, FileAccess.Read)),
                CodePage.UNICODE,
                Embed.YES);
        f1.SetSize(11f);

        Font f2 = new Font(pdf, new BufferedStream(
                new FileStream(
                        "fonts/Android/DroidSansFallback.ttf", FileMode.Open, FileAccess.Read)),
                CodePage.UNICODE,
                Embed.YES);
        f2.SetSize(11f);

        Page page = new Page(pdf, Letter.LANDSCAPE);

        StreamReader reader = new StreamReader(
                new FileStream("data/report.csv", FileMode.Open));

        float y = 50f;
        String str = null;
        while ((str = reader.ReadLine()) != null) {
            new TextLine(f1, str)
                    .SetFallbackFont(f2)
                    .SetLocation(50f, y += 20f)
                    .DrawOn(page);
        }
        reader.Close();

        float x = 50f;
        y = 300f;

        TextLine text = new TextLine(f2);
        StringBuilder buf = new StringBuilder();
        for (int i = 0x2701; i < 0x27bf; i++) {
            if (i % 16 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x, y += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        pdf.Close();
    }


    public static void Main(String[] args) {
        new Example_28();
    }

}   // End of Example_28.cs
