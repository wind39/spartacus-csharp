using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_01.cs
 *  We will draw the American flag using Box, Line and Point objects.
 */
public class Example_01 {

    public Example_01() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_01.pdf", FileMode.Create)));

        Page page = new Page(pdf, Letter.PORTRAIT);

        Box flag = new Box();
        flag.SetLocation(100.0f, 100.0f);
        flag.SetSize(190.0f, 100.0f);
        flag.SetColor(Color.white);
        flag.DrawOn(page);

        float sw = 7.69f;       // stripe width
        Line stripe = new Line(0.0f, sw/2, 190.0f, sw/2);
        stripe.SetWidth(sw);
        stripe.SetColor(Color.oldgloryred);
        for (int row = 0; row < 7; row++) {
            stripe.PlaceIn(flag, 0.0f, row * 2 * sw);
            stripe.DrawOn(page);
        }

        Box union = new Box();
        union.SetSize(76.0f, 53.85f);
        union.SetColor(Color.oldgloryblue);
        union.SetFillShape(true);
        union.PlaceIn(flag, 0.0f, 0.0f);
        union.DrawOn(page);

        float h_si = 12.6f;    // horizontal star interval
        float v_si = 10.8f;    // vertical star interval
        Point star = new Point(h_si/2, v_si/2);
        star.SetShape(Point.STAR);
        star.SetRadius(3.0f);
        star.SetColor(Color.white);
        star.SetFillShape(true);

        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 5; col++) {
                star.PlaceIn(union, row * h_si, col * v_si);
                star.DrawOn(page);
            }
        }
        star.SetLocation(h_si, v_si);
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 4; col++) {
                star.PlaceIn(union, row * h_si, col * v_si);
                star.DrawOn(page);
            }
        }

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_01();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_01.cs
