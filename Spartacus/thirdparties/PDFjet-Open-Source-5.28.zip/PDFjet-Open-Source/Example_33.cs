using System;
using System.IO;

using PDFjet.NET;


/**
 *  Example_33.cs
 *
 */
public class Example_33 {

    public Example_33() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_33.pdf", FileMode.Create)));

        Page page = new Page(pdf, A4.PORTRAIT);

        Image image = new Image(
                pdf,
                new FileStream("images/photoshop.jpg", FileMode.Open, FileAccess.Read),
                ImageType.JPG);
        image.SetLocation(10f, 10f);
        image.ScaleBy(0.25f);
        image.DrawOn(page);

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_33();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_33.cs
