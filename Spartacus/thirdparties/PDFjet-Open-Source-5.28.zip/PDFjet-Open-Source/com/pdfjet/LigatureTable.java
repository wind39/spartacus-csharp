package com.pdfjet;

class LigatureTable {
    int ligGlyph;
    int compCount;
    int[] component;    // [compCount - 1]
}
