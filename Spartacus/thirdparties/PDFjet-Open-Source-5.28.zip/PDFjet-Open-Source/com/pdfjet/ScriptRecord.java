package com.pdfjet;

class ScriptRecord {
    byte[] scriptTag;   // 4-byte ScriptTag identifier
    int scriptOffset;   // Offset to Script table-from beginning of ScriptList
}
