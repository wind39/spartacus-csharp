package com.pdfjet;

class ChainSubRuleSet {
    int chainSubRuleCount;
    int[] chainSubRule;     // [chainSubRuleCount]
}
