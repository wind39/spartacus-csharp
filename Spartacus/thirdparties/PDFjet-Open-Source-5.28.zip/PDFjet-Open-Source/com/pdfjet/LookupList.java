package com.pdfjet;

class LookupList {
    int lookupCount;
    int[] lookup;       // [lookupCount]
}
