package com.pdfjet;

class ChainContextSubstFormat2 {
    int substFormat;
    int coverage;
    int backtrackClassDef;
    int inputClassDef;
    int lookaheadClassDef;
    int chainSubClassSetCount;
    int[] chainSubClassSet;     // [chainSubClassSetCount]
}
