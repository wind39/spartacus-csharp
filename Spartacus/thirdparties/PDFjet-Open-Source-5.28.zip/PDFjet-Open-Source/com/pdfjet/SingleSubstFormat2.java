package com.pdfjet;

class SingleSubstFormat2 {
    int substFormat;
    int coverage;
    int glyphCount;
    int[] substitute;   // [glyphCount]
}
