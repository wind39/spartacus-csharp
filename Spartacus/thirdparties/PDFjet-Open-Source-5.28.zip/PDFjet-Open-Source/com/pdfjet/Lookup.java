package com.pdfjet;

class Lookup {
    int lookupType;
    int lookupFlag;
    int subTableCount;
    int[] subTable;         // [subTableCount]
    int markFilteringSet;
}
