package com.pdfjet;

class ClassDefFormat2 {
    int classFormat;                        // Format identifier-format = 2
    int classRangeCount;                    // Number of ClassRangeRecords
    ClassRangeRecord[] classRangeRecord;    // Array of ClassRangeRecords-ordered by Start GlyphID
}
