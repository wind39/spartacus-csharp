package com.pdfjet;

class SingleSubstFormat1 {
    int substFormat;
    int coverage;
    int deltaGlyphID;
}
