import java.io.*;

import com.pdfjet.*;


/**
 *  Example_06.java
 *
 */
class Example_06 {

    public Example_06() throws Exception {

        PDF pdf = new PDF(
                new BufferedOutputStream(
                        new FileOutputStream("Example_06.pdf")));

        Font f1 = new Font(
                pdf,
                getClass().getResourceAsStream(
                        "fonts/Android/DroidSerif-Regular.ttf"),
                CodePage.CP1252,
                Embed.YES);

        Font f2 = new Font(
                pdf,
                getClass().getResourceAsStream(
                        "fonts/Android/DroidSerif-Regular.ttf"),
                CodePage.CP1251,
                Embed.YES);
        f2.setItalic(true);
        
        Font f3 = new Font(
                pdf,
                getClass().getResourceAsStream(
                        "fonts/Android/DroidSerif-Regular.ttf"),
                CodePage.CP1253,
                Embed.YES);

        Font f4 = new Font(pdf, CoreFont.ZAPF_DINGBATS);

        Page page = new Page(pdf, Letter.PORTRAIT);

        float x_pos = 50f;
        float y_pos = 0f;

        f1.setSize(20f);
        f2.setSize(20f);
        f3.setSize(20f);
        f4.setSize(18f);

        TextLine text = new TextLine(f1);
        text.setLocation(x_pos, y_pos);
        StringBuilder buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.setText(buf.toString());
                text.setLocation(x_pos, y_pos += 24f);
                text.drawOn(page);
                buf = new StringBuilder();
            }
            buf.append((char) i);
        }

        text.setFont(f2);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.setText(buf.toString());
                text.setLocation(x_pos, y_pos += 24f);
                text.drawOn(page);
                buf = new StringBuilder();
            }
            buf.append((char) i);
        }

        text.setFont(f3);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i == 210 || i == 242) {
                // Character 210 is not mapped in the 1253 code page
                // Character 242 - "SIGMA FINAL" is not available in this font
                continue;
            }
            if (i % 32 == 0) {
                text.setText(buf.toString());
                text.setLocation(x_pos, y_pos += 24f);
                text.drawOn(page);
                buf = new StringBuilder();
            }
            buf.append((char) i);
        }

        text.setFont(f4);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.setText(buf.toString());
                text.setLocation(x_pos, y_pos += 22f);
                text.setUnderline(true);
                text.drawOn(page);
                buf = new StringBuilder();
            }
            buf.append((char) i);
        }

        pdf.close();
    }


    public static void main(String[] args) {
        try {
            new Example_06();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}   // End of Example_06.java
