using System;
using System.Text;
using System.IO;

using PDFjet.NET;


/**
 *  Example_06.cs
 *
 */
class Example_06 {

    public Example_06() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_06.pdf", FileMode.Create)));

        Font f1 = new Font(
                pdf,
                new FileStream(
                        "fonts/Android/DroidSerif-Regular.ttf",
                        FileMode.Open,
                        FileAccess.Read),
                CodePage.CP1252,
                Embed.YES);

        Font f2 = new Font(
                pdf,
                new FileStream(
                        "fonts/Android/DroidSerif-Regular.ttf",
                        FileMode.Open,
                        FileAccess.Read),
                CodePage.CP1252,
                Embed.YES);
        f2.SetItalic(true);

        Font f3 = new Font(
                pdf,
                new FileStream(
                        "fonts/Android/DroidSerif-Regular.ttf",
                        FileMode.Open,
                        FileAccess.Read),
                CodePage.CP1253,
                Embed.YES);

        Font f4 = new Font(pdf, CoreFont.ZAPF_DINGBATS);

        Page page = new Page(pdf, Letter.PORTRAIT);

        float x_pos = 50f;
        float y_pos = 0f;

        f1.SetSize(20f);
        f2.SetSize(20f);
        f3.SetSize(20f);
        f4.SetSize(20f);

        TextLine text = new TextLine(f1);
        text.SetLocation(x_pos, y_pos);
        StringBuilder buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        text.SetFont(f2);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        text.SetFont(f3);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i == 210 || i == 242) {
                // Char 210 is not mapped in the 1253 code page
                // Char 242 - "SIGMA FINAL" is not available in this font
                continue;
            }
            if (i % 32 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        text.SetFont(f4);
        buf = new StringBuilder();
        for (int i = 32; i <= 256; i++) {
            if (i % 32 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.SetUnderline(true);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_06();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_06.cs
