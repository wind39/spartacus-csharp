using System;
using System.IO;

using PDFjet.NET;


/**
 *  Example_37.cs
 *
 */
public class Example_37 {

    public Example_37() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_37.pdf", FileMode.Create)));

        Page page = new Page(pdf, A4.PORTRAIT);

        page.SetBrushColor(Color.slategray);
        // page.setBrushColor(Color.yellow);
        page.FillRect(90f, 40f, 340f, 240f);

        Image image1 = new Image(
                pdf,
                new BufferedStream(new FileStream(
                        "images/indexed-color-with-alpha.png", FileMode.Open, FileAccess.Read)),
                ImageType.PNG);
        image1.SetLocation(90f, 40f);
        image1.DrawOn(page);

        pdf.Close();
    }


    public static void Main(String[] args) {
        new Example_37();
    }

}   // End of Example_37.cs
