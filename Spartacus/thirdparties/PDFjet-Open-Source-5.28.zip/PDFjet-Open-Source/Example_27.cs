using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_27.cs
 *
 */
public class Example_27 {

    public Example_27() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_27.pdf", FileMode.Create)));

        Page page = new Page(pdf, Letter.PORTRAIT);

        // Thai font
        FileStream fis = new FileStream(
                "fonts/Android/DroidSansThai.ttf",
                FileMode.Open,
                FileAccess.Read);
        Font f1 = new Font(pdf, fis, CodePage.UNICODE, Embed.YES);
        f1.SetSize(16f);

        // Latin font
        fis = new FileStream(
                "fonts/Android/DroidSans.ttf",
                FileMode.Open,
                FileAccess.Read);
        Font f2 = new Font(pdf, fis, CodePage.UNICODE, Embed.YES);
        f2.SetSize(16f);

        float x_pos = 50f;
        float y_pos = 20f;

        TextLine text = new TextLine(f1);
        text.SetFallbackFont(f2);
        text.SetLocation(x_pos, y_pos);

        StringBuilder buf = new StringBuilder();
        for (int i = 0x0E01; i < 0x0E5B; i++) {
            if (i % 16 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            if (i > 0x0E30 && i < 0x0E3B) {
                buf.Append("\u0E01");
            }
            if (i > 0x0E46 && i < 0x0E4F) {
                buf.Append("\u0E2D");
            }
            buf.Append((char) i);
        }

        text.SetText(buf.ToString());
        text.SetLocation(x_pos, y_pos += 24.0f);
        text.DrawOn(page);

        y_pos += 30f;
        String str = "\u0E1C\u0E1C\u0E36\u0E49\u0E07 abc 123";
        text.SetText(str);
        text.SetLocation(x_pos, y_pos);
        text.DrawOn(page);

        // Hebrew font
        fis = new FileStream(
                "fonts/Android/DroidSansHebrew-Regular.ttf",
                FileMode.Open,
                FileAccess.Read);
        Font f3 = new Font(pdf, fis, CodePage.UNICODE, Embed.YES);
        f3.SetSize(16f);

        y_pos += 50f;
        text = new TextLine(f3);
        text.SetFallbackFont(f2);
        text.SetLocation(x_pos, y_pos);

        buf = new StringBuilder();
        for (int i = 0x05D1; i <= 0x05F4; i++) {
            if (i % 16 == 0) {
                text.SetText(buf.ToString());
                text.SetLocation(x_pos, y_pos += 24f);
                text.DrawOn(page);
                buf = new StringBuilder();
            }
            buf.Append((char) i);
        }

        text.SetText(buf.ToString());
        text.SetLocation(x_pos, y_pos += 24f);
        text.DrawOn(page);

        y_pos += 30f;

        str = Bidi.ReorderVisually("'ארגון אליפות הארץ 2011 שלב ב");
        TextLine textLine = new TextLine(f3, str);
        textLine.SetFallbackFont(f2);
        textLine.SetLocation(400f - f3.StringWidth(f2, str), y_pos);
        textLine.DrawOn(page);

        // Draw line to prove that the stringWidth(f1, f2, str) method is working correctly.
        page.MoveTo(400f, 280f);
        page.LineTo(400f, 320f);
        page.StrokePath();

        pdf.Close();
    }


    public static void Main(String[] args) {
        new Example_27();
    }

}   // End of Example_27.cs
