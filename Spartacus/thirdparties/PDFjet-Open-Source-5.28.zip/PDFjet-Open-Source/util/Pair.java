package util;

public class Pair {
    String key;
    String value;
}
