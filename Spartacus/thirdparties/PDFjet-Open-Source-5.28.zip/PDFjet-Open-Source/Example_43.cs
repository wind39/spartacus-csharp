using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_43.java
 *
 */
public class Example_43 {

    public Example_43() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_43.pdf", FileMode.Create)));

        Font f1 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        Font f2 = new Font(pdf, CoreFont.HELVETICA);

        Page page = new Page(pdf, Letter.PORTRAIT);

        List<Paragraph> paragraphs = new List<Paragraph>();
        Paragraph p1 = new Paragraph();
        TextLine tl1 = new TextLine(f2,
"The Swiss Confederation was founded in 1291 as a defensive alliance among three cantons. In succeeding years, other localities joined the original three. The Swiss Confederation secured its independence from the Holy Roman Empire in 1499. Switzerland's sovereignty and neutrality have long been honored by the major European powers, and the country was not involved in either of the two World Wars. The political and economic integration of Europe over the past half century, as well as Switzerland's role in many UN and international organizations, has strengthened Switzerland's ties with its neighbors. However, the country did not officially become a UN member until 2002.");
        p1.Add(tl1);

        Paragraph p2 = new Paragraph();
        TextLine tl2 = new TextLine(f2,
"Even so, unemployment has remained at less than half the EU average.");
        p2.Add(tl2);

        paragraphs.Add(p1);
        paragraphs.Add(p2);

        Text text = new Text(paragraphs);
        text.SetLocation(50f, 50f);
        text.SetWidth(500f);
        float[] xy = text.DrawOn(page);
// Console.WriteLine("x == " + xy[0]);
// Console.WriteLine("y == " + xy[1]);

        List<float[]> points = text.GetBeginParagraphPoints();
        foreach (float[] point in points) {
// Console.WriteLine("x_begin == " + point[0]);
// Console.WriteLine("y_begin == " + point[1]);
        }

        points = text.GetEndParagraphPoints();
        foreach (float[] point in points) {
Console.WriteLine("x_end == " + point[0]);
Console.WriteLine("y_end == " + point[1]);
            page.DrawRect(point[0], point[1], 15f, 15f);
        }

        pdf.Close();
    }


    public static void Main(String[] args) {
        new Example_43();
    }

}   // End of Example_43.cs
