using System;
using System.IO;

using PDFjet.NET;


/**
 *  Example_25.cs
 *
 */
public class Example_25 {

    public Example_25() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_25.pdf", FileMode.Create)));

        Font f1 = new Font(pdf, CoreFont.HELVETICA);
        Font f2 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        Font f3 = new Font(pdf, CoreFont.HELVETICA);
        Font f4 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        Font f5 = new Font(pdf, CoreFont.HELVETICA);
        Font f6 = new Font(pdf, CoreFont.HELVETICA_BOLD);
        
        Page page = new Page(pdf, Letter.PORTRAIT);
        
        CompositeTextLine composite = new CompositeTextLine(50f, 50f);
        composite.SetFontSize(14f);

        TextLine text1 = new TextLine(f1, "C");
        TextLine text2 = new TextLine(f2, "6");
        TextLine text3 = new TextLine(f3, "H");        
        TextLine text4 = new TextLine(f4, "12");
        TextLine text5 = new TextLine(f5, "O");        
        TextLine text6 = new TextLine(f6, "6");

        text1.SetColor(Color.dodgerblue);
        text3.SetColor(Color.dodgerblue);
        text5.SetColor(Color.dodgerblue);

        text2.SetTextEffect(Effect.SUBSCRIPT);
        text4.SetTextEffect(Effect.SUBSCRIPT);
        text6.SetTextEffect(Effect.SUBSCRIPT);
        
        composite.AddComponent(text1);
        composite.AddComponent(text2);
        composite.AddComponent(text3);
        composite.AddComponent(text4);
        composite.AddComponent(text5);
        composite.AddComponent(text6);

        composite.DrawOn(page);

        CompositeTextLine composite2 = new CompositeTextLine(50f, 100f);
        composite2.SetFontSize(14f);

        text1 = new TextLine(f1, "SO");
        text2 = new TextLine(f2, "4");
        text3 = new TextLine(f4, "2-"); // Use bold font here        

        text2.SetTextEffect(Effect.SUBSCRIPT);
        text3.SetTextEffect(Effect.SUPERSCRIPT);

        composite2.AddComponent(text1);
        composite2.AddComponent(text2);
        composite2.AddComponent(text3);

        composite2.DrawOn(page);
        composite2.SetLocation(100f, 150f);
        composite2.DrawOn(page);

        float[] yy = composite2.GetMinMax();
        Line line1 = new Line(50f, yy[0], 200f, yy[0]);
        Line line2 = new Line(50f, yy[1], 200f, yy[1]);
        line1.DrawOn(page);
        line2.DrawOn(page);

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_25();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_25.cs
