using System;
using System.IO;
using System.Text;

using PDFjet.NET;


/**
 *  Example_12.cs
 *
 */
public class Example_12 {

    public static void Main(String[] args) {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_12.pdf", FileMode.Create)));

        Font f1 = new Font(pdf, CoreFont.HELVETICA);

        Page page = new Page(pdf, Letter.PORTRAIT);

        StringBuilder buf = new StringBuilder();
        StreamReader reader = new StreamReader(
                new FileStream("Example_12.cs", FileMode.Open));
        String line = null;
        while ((line = reader.ReadLine()) != null) {
            buf.Append(line);
            // Both CR and LF are required by the scanner!
            buf.Append((char) 13);
            buf.Append((char) 10);
        }
        reader.Close();

        BarCode2D code2D = new BarCode2D(buf.ToString());
        code2D.SetLocation(100f, 60f);
        code2D.DrawOn(page);

        TextLine text = new TextLine(f1,
                "PDF417 barcode containing the program that created it.");
        text.SetLocation(100f, 40f);
        text.DrawOn(page);

        pdf.Close();
    }

}   // End of Example_12.cs
