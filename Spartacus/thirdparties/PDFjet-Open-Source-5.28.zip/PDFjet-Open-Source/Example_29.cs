using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Text;

using PDFjet.NET;


/**
 *  Example_29.cs
 */
public class Example_29 {

    public Example_29() {

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_29.pdf", FileMode.Create)));

        Page page = new Page(pdf, Letter.PORTRAIT);
    
        Font font = new Font(pdf, CoreFont.HELVETICA);
        font.SetSize(16f);
    
        Paragraph p = new Paragraph();
        p.Add(new TextLine(font, "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum interdum elit, quis vehicula urna interdum quis. Phasellus gravida ligula quam, nec blandit nulla. Sed posuere, lorem eget feugiat placerat, ipsum nulla euismod nisi, in semper mi nibh sed elit. Mauris libero est, sodales dignissim congue sed, pulvinar non ipsum. Sed risus nisi, ultrices nec eleifend at, viverra sed neque. Integer vehicula massa non arcu viverra ullamcorper. Ut id tellus id ante mattis commodo. Donec dignissim aliquam tortor, eu pharetra ipsum ullamcorper in. Vivamus ultrices imperdiet iaculis."));
    
        TextColumn column = new TextColumn();
        column.SetLocation(10f, 0f);
        column.SetSize(540f, 0f);
        // column.SetLineBetweenParagraphs(true);
        column.SetLineBetweenParagraphs(false);
        column.AddParagraph(p);
    
        Dimension dim0 = column.GetSize();
        Point point1 = column.DrawOn(page);
        Point point2 = column.DrawOn(page, false);
        Dimension dim1 = column.GetSize();
        Dimension dim2 = column.GetSize();
        Dimension dim3 = column.GetSize();
    
        Console.WriteLine("height0: " + dim0.GetHeight());
        Console.WriteLine("point1.x: " + point1.GetX() + "    point1.y " + point1.GetY());
        Console.WriteLine("point2.x: " + point2.GetX() + "    point2.y " + point2.GetY());
        Console.WriteLine("height1: " + dim1.GetHeight());
        Console.WriteLine("height2: " + dim2.GetHeight());
        Console.WriteLine("height3: " + dim3.GetHeight());
        Console.WriteLine();

        column.RemoveLastParagraph();
        column.SetLocation(10f, point2.GetY() + 10f);
        p = new Paragraph();
        p.Add(new TextLine(font, "Peter Blood, bachelor of medicine and several other things besides, smoked a pipe and tended the geraniums boxed on the sill of his window above Water Lane in the town of Bridgewater."));
        column.AddParagraph(p);

        Dimension dim4 = column.GetSize();
        Point point = column.DrawOn(page);  // Draw the updated text column
        Console.WriteLine("point.x: " + point.GetX() + "    point.y " + point.GetY());
        Console.WriteLine("height4: " + dim4.GetHeight());

        Box box = new Box();
        box.SetLocation(point.GetX(), point.GetY() + 10f);
        box.SetSize(540f, 25f);
        box.SetLineWidth(2f);
        box.SetColor(Color.darkblue);
        box.DrawOn(page);

        pdf.Close();
    }


    public static void Main(String[] args) {
        try {
            new Example_29();
        }
        catch (Exception e) {
            Console.WriteLine(e.StackTrace);
        }
    }

}   // End of Example_29.cs
