import java.io.*;
import java.util.*;

import com.pdfjet.*;


/**
 *  Example_31.java
 *
 */
public class Example_31 {

    public Example_31() throws Exception {

        PDF pdf = new PDF(
                new BufferedOutputStream(
                        new FileOutputStream("Example_31.pdf")));

        Page page = new Page(pdf, Letter.PORTRAIT);

        Font f1 = new Font(pdf,
                getClass().getResourceAsStream(
                        "fonts/Android/DroidSansDevanagari-Regular.ttf"),
                CodePage.UNICODE,
                Embed.YES);
        f1.setSize(15f);
/*
        Font f2 = new Font(pdf,
                getClass().getResourceAsStream(
                        "fonts/Android/DroidSans.ttf"),
                CodePage.UNICODE,
                Embed.YES);
        f2.setSize(15f);
*/
        StringBuilder buf = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream("data/marathi.txt"), "UTF-8"));
        String line = null;
        while ((line = reader.readLine()) != null) {
            buf.append(line + "\n");
        }
        reader.close();

        TextBox textBox = new TextBox(f1, buf.toString(), 500f, 300f);
        // textBox.setFallbackFont(f2);
        textBox.setLocation(50f, 50f);
        textBox.setNoBorders();
        textBox.drawOn(page);

        pdf.close();
    }


    public static void main(String[] args) throws Exception {
        new Example_31();
    }

}   // End of Example_31.java
