using System;
using System.Collections.Generic;
using System.IO;

using PDFjet.NET;


/**
 *  Example_19.cs
 *
 */
class Example_19 {

    public Example_19(String fileNumber, String fileName) {

        BufferedStream bis = new BufferedStream(
                new FileStream(fileName, FileMode.Open));

        PDF pdf = new PDF(new BufferedStream(
                new FileStream("Example_19_" + fileNumber + ".pdf", FileMode.Create)));

        SortedDictionary<Int32, PDFobj> objects = pdf.Read(bis);
        bis.Close();

        List<PDFobj> pages = pdf.GetPageObjects(objects);

        Font f1 = pages[0].AddFontResource(CoreFont.HELVETICA, objects);
        // Font f1 = pages[0].AddFontResource(CoreFont.COURIER, objects);
        // Font f1 = pages[0].AddFontResource(CoreFont.TIMES_ROMAN, objects);
        // Font f1 = pages[0].AddFontResource(CoreFont.ZAPF_DINGBATS, objects);
        f1.SetSize(14f);

        Page page = new Page(pdf, pages[0].GetPageSize(), false);
        page.SetPenColor(Color.blue);
        page.SetPenWidth(1.5f);
        page.DrawRect(250f, 210f, 50f, 50f);
        page.SetBrushColor(Color.green);
        page.DrawString(f1, "Hello, World!", 300f, 300f);

        pages[0].AddContent(page.GetContent(), objects);

        pdf.AddObjects(objects);

        pdf.Close();
    }


    public static void Main(String[] args) {
        new Example_19("00", "Example_07.pdf");
    }

}   // End of Example_19.cs
