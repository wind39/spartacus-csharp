#!/bin/bash
java -cp .:PDFjet.jar util.PNGtoJET $1
